Moved to http://oclif.io/docs/introduction
