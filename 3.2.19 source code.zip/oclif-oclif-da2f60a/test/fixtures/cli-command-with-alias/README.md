# cli-command-with-alias

This file is a test for running `oclif-dev readme` with aliases. If the --no-aliases flag
is passed as a flag, no aliases should be in the README.

<!-- toc -->
<!-- tocstop -->

# Usage

<!-- usage -->
<!-- usagestop -->

# Commands

<!-- commands -->
<!-- commandsstop -->
