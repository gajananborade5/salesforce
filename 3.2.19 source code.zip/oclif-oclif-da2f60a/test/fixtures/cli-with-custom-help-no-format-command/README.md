# cli-with-custom-help

This file is a test for running `oclif-dev readme` in the presence of
a custom help class. It should use the custom help class to generate
the command documentation below. The test suite resets this file after
each test.

<!-- toc -->
<!-- tocstop -->

# Usage

<!-- usage -->
<!-- usagestop -->

# Commands

<!-- commands -->
<!-- commandsstop -->
