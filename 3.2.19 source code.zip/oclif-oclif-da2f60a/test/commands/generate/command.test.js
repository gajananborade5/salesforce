require('../../run')(module.filename)
