require('../run')(module.filename)
