// declare module 'yeoman-environment'
